from django.db import models

class Attend(models.Model):
    rollno=models.CharField(max_length=50)
    name=models.CharField(max_length=50)
    status=models.CharField(max_length=50) #p for present,a for absent

    class Meta:
        db_table="attendance"
